/* Blog Layout - category list expand/collapse */

(function () {
  function findDirectLink(li) {
    // Prefer :scope > a when available; fall back to direct children.
    var link = null;

    try {
      link = li.querySelector(':scope > a');
    } catch (e) {
      link = null;
    }

    if (!link) {
      var children = li.children;
      for (var i = 0; i < children.length; i++) {
        var el = children[i];
        if (el && el.tagName && el.tagName.toUpperCase() === 'A') {
          link = el;
          break;
        }
      }
    }

    return link;
  }

  function getToggleSubcategoriesAriaLabel(root) {
    if (
      typeof FBLFrontendL10n !== 'undefined' &&
      FBLFrontendL10n &&
      typeof FBLFrontendL10n.toggleSubcategoriesAriaLabel === 'string' &&
      FBLFrontendL10n.toggleSubcategoriesAriaLabel
    ) {
      return FBLFrontendL10n.toggleSubcategoriesAriaLabel;
    }

    if (
      root &&
      root.dataset &&
      typeof root.dataset.fblToggleAriaLabel === 'string' &&
      root.dataset.fblToggleAriaLabel
    ) {
      return root.dataset.fblToggleAriaLabel;
    }

    return '';
  }

  function findDirectChildrenList(li) {
    var children = li.children;
    for (var i = 0; i < children.length; i++) {
      var el = children[i];
      if (
        el &&
        el.tagName &&
        el.tagName.toUpperCase() === 'UL' &&
        el.classList &&
        el.classList.contains('children')
      ) {
        return el;
      }
    }

    return null;
  }

  function syncChildrenVisibility(li, open) {
    var childrenList = findDirectChildrenList(li);
    if (!childrenList) return;

    childrenList.style.display = open ? 'block' : 'none';
  }

  function initCategoryToggles() {
    var root = document.querySelector('.fbl-sidebar-categories .fbl-category-list');
    if (!root) return;

    var items = root.querySelectorAll('li');
    for (var i = 0; i < items.length; i++) {
      (function (li) {
        if (li.querySelector('.fbl-cat-toggle')) return;
        if (!findDirectChildrenList(li)) return;

        var link = findDirectLink(li);
        if (!link) return;

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'fbl-cat-toggle';
        btn.setAttribute('aria-label', getToggleSubcategoriesAriaLabel(root));
        btn.setAttribute('aria-expanded', 'false');

        li.insertBefore(btn, link);

        var active =
          li.classList.contains('current-cat') ||
          li.classList.contains('current-cat-parent') ||
          li.classList.contains('current-cat-ancestor');

        if (active) {
          li.classList.add('is-open');
          btn.setAttribute('aria-expanded', 'true');
        }

        syncChildrenVisibility(li, active);

        btn.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          var open = li.classList.toggle('is-open');
          btn.setAttribute('aria-expanded', open ? 'true' : 'false');
          syncChildrenVisibility(li, open);
        });
      })(items[i]);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initCategoryToggles);
  } else {
    initCategoryToggles();
  }
})();
