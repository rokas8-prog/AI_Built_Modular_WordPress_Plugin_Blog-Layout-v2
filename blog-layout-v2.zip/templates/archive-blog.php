<?php
/**
 * Custom archive template for blog layout
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$fbl                              = FBL_Blog_Layout::instance();
$opts                             = $fbl->options;
$sidebar_state                    = $fbl->get_archive_sidebar_visibility_state( $opts );
$category_block                   = $fbl->get_archive_category_block_payload( $opts );
$archive_primary_wrapper_attributes = $fbl->get_archive_primary_wrapper_attributes();

get_header();
?>

<div id="primary" <?php echo $archive_primary_wrapper_attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized at helper boundary. ?>>
    <main id="main" class="site-main fbl-wrapper">
        <div class="<?php echo esc_attr( $fbl->get_archive_container_classes() ); ?>">


        <?php
        $grid_classes = $fbl->get_grid_class_string( $opts );
        ?>
        <div class="<?php echo esc_attr( $fbl->get_main_layout_class_string( $opts ) ); ?>">
            <div class="fbl-content-area">

        <?php
        $show_hero    = $fbl->should_render_archive_hero( $opts );
        $hero_payload = $fbl->get_archive_hero_payload( $opts );

        if ( $show_hero ) :
            $hero_title   = $hero_payload['title'];
            $hero_sub     = $hero_payload['subtitle'];
            $hero_btn_txt = $hero_payload['button_text'];
            $hero_btn_url = $hero_payload['button_url'];
            ?>
            <section class="fbl-hero">
                <div class="fbl-hero-inner">
                    <?php if ( $hero_title ) : ?>
                        <h1 class="fbl-hero-title"><?php echo esc_html( $hero_title ); ?></h1>
                    <?php endif; ?>

                    <?php if ( $hero_sub ) : ?>
                        <p class="fbl-hero-subtitle"><?php echo esc_html( $hero_sub ); ?></p>
                    <?php endif; ?>

                    <?php if ( $hero_btn_txt && $hero_btn_url ) : ?>
                        <a href="<?php echo esc_url( $hero_btn_url ); ?>" class="fbl-hero-btn">
                            <?php echo esc_html( $hero_btn_txt ); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

                <?php if ( have_posts() ) : ?>
                    <div class="<?php echo esc_attr( $grid_classes ); ?>">

                        <?php
                        while ( have_posts() ) :
                            the_post();
                            ?>
                            <article id="post-<?php the_ID(); ?>" <?php post_class( 'fbl-card' ); ?>>
                                <a href="<?php the_permalink(); ?>" class="fbl-card-thumb">
                                    <?php
                                    $archive_card_thumbnail_html = $fbl->get_archive_card_thumbnail_html( get_the_ID() );
                                    // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- intended safe helper fragment.
                                    echo $archive_card_thumbnail_html;
                                    ?>
                                </a>

                                <div class="fbl-card-body">
                                    <?php if ( ! empty( $opts['show_meta_category'] ) ) : ?>
                                        <div class="fbl-card-category">
                                            <?php
                                            $primary_category_name = $fbl->get_archive_card_primary_category_name( get_the_ID() );
                                            if ( '' !== $primary_category_name ) {
                                                echo '<span>' . esc_html( $primary_category_name ) . '</span>';
                                            }
                                            ?>
                                        </div>
                                    <?php endif; ?>

                                    <h2 class="fbl-card-title">
                                        <a href="<?php the_permalink(); ?>">
                                            <?php the_title(); ?>
                                        </a>
                                    </h2>

                                    <?php $meta_payload = $fbl->get_archive_card_meta_payload( get_the_ID(), $opts ); ?>
                                    <?php if ( $meta_payload['show'] ) : ?>
                                        <div class="fbl-card-meta">
                                            <?php if ( $meta_payload['show_date'] ) : ?>
                                                <span class="fbl-meta-date"><?php echo esc_html( $meta_payload['date'] ); ?></span>
                                            <?php endif; ?>

                                            <?php if ( $meta_payload['show_readtime'] ) : ?>
                                                <?php if ( $meta_payload['show_separator'] ) : ?>
                                                    <span class="fbl-meta-separator">•</span>
                                                <?php endif; ?>
                                                <span class="fbl-meta-readtime">
                                                    <?php
                                                    $read_time_text = sprintf( esc_html__( '%d min read', 'blog-layout' ), $meta_payload['read_time'] );
                                                    echo esc_html( apply_filters( 'fbl_read_time_text', $read_time_text, $meta_payload['read_time'], get_the_ID(), $meta_payload ) );
                                                    ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>

                                    <div class="fbl-card-excerpt">
                                        <?php
                                        $excerpt = $fbl->get_archive_card_excerpt_text( get_the_ID(), $opts );
                                        echo esc_html( $excerpt );
                                        ?>
                                    </div>

                                    <div class="fbl-card-footer">
                                        <a href="<?php the_permalink(); ?>" class="fbl-card-btn">
                                            <?php echo esc_html( apply_filters( 'fbl_archive_read_more_text', __( 'Read more', 'blog-layout' ), get_the_ID() ) ); ?>
                                        </a>
                                    </div>
                                </div>
                            </article>
                        <?php endwhile; ?>

                    </div><!-- .fbl-grid -->

                    <div class="fbl-pagination">
                        <?php
                        the_posts_pagination( $fbl->get_archive_pagination_args() );
                        ?>
                    </div>

                <?php else : ?>

                    <p><?php esc_html_e( 'No posts found.', 'blog-layout' ); ?></p>

                <?php endif; ?>

            </div><!-- .fbl-content-area -->

            <?php if ( $sidebar_state['show_sidebar'] ) : ?>
                <aside class="fbl-sidebar">

                    <?php if ( $category_block['show'] ) : ?>
                        <section class="widget fbl-sidebar-categories">
                            <?php if ( ! empty( $category_block['title'] ) ) : ?>
                                <h3 class="widget-title"><?php echo esc_html( $category_block['title'] ); ?></h3>
                            <?php endif; ?>

                            <ul class="fbl-category-list" data-fbl-toggle-aria-label="<?php echo esc_attr( $category_block['toggle_aria_label'] ); ?>">
                                <?php
                                wp_list_categories(
                                    array(
                                        'title_li'   => '',
                                        'show_count' => false,
                                    )
                                );
                                ?>
                            </ul>
                        </section>
                    <?php endif; ?>

                    <?php if ( $sidebar_state['use_widget_sidebar'] ) : ?>
                        <?php dynamic_sidebar( 'fbl-blog-sidebar' ); ?>
                    <?php else : ?>
                        <?php if ( $sidebar_state['show_default_box'] ) : ?>
                            <?php $sidebar_default = $fbl->get_sidebar_default_box_payload( $opts ); ?>
                            <section class="widget fbl-sidebar-default-box">
                                <?php if ( ! empty( $sidebar_default['title'] ) ) : ?>
                                    <h3 class="widget-title"><?php echo esc_html( $sidebar_default['title'] ); ?></h3>
                                <?php endif; ?>

                                <?php if ( ! empty( $sidebar_default['text'] ) ) : ?>
                                    <?php $sidebar_default_text_html_safe = $fbl->render_plain_textarea_content_with_paragraphs( $sidebar_default['text'] ); ?>
                                    <?php echo $sidebar_default_text_html_safe; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized at helper boundary. ?>
                                <?php endif; ?>

                                <?php if ( ! empty( $sidebar_default['button_text'] ) && ! empty( $sidebar_default['button_url'] ) ) : ?>
                                    <a class="fbl-sidebar-default-btn" href="<?php echo esc_url( $sidebar_default['button_url'] ); ?>">
                                        <?php echo esc_html( $sidebar_default['button_text'] ); ?>
                                    </a>
                                <?php endif; ?>
                            </section>
                        <?php endif; ?>
                    <?php endif; ?>
                </aside>
            <?php endif; ?>
        </div><!-- .fbl-main-layout -->

            </div><!-- .fbl-container -->
    </main><!-- #main -->
</div><!-- #primary -->

<?php
get_footer();
