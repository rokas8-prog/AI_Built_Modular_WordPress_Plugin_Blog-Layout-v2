<?php
/**
 * Plugin Name: Blog-Layout
 * Description: Custom blog layout with hero, card grid/list, configurable sidebar with categories & widgets, responsive options, and CTA under single posts.
 * Version: 2.0
 * Author: Rokas Golcas
 * Text Domain: blog-layout
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}


if ( ! defined( 'FBL_PLUGIN_VERSION' ) ) {
    $fbl_plugin_data_version = '';
    if ( function_exists( 'get_file_data' ) ) {
        $fbl_plugin_data = get_file_data( __FILE__, array( 'Version' => 'Version' ), 'plugin' );
        $fbl_plugin_data_version = isset( $fbl_plugin_data['Version'] ) ? (string) $fbl_plugin_data['Version'] : '';
    }
    define( 'FBL_PLUGIN_VERSION', '' !== $fbl_plugin_data_version ? $fbl_plugin_data_version : '1.1.9' );
}

require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-fbl-admin-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-fbl-content-utilities-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-fbl-asset-css-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-fbl-public-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-fbl-context-defaults-trait.php';
require_once plugin_dir_path( __FILE__ ) . 'includes/traits/class-fbl-archive-template-data-trait.php';

if ( ! class_exists( 'FBL_Blog_Layout' ) ) :

class FBL_Blog_Layout {

    private static $instance = null;
    public $options = array();

    use FBL_Blog_Layout_Admin_Trait;
    use FBL_Blog_Layout_Content_Utilities_Trait;
    use FBL_Blog_Layout_Asset_CSS_Trait;
    use FBL_Blog_Layout_Public_Trait;
    use FBL_Blog_Layout_Context_Defaults_Trait;
    use FBL_Blog_Layout_Archive_Template_Data_Trait;

    public static function instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $saved          = get_option( 'fbl_options', array() );
        $this->options  = wp_parse_args( $saved, $this->default_options() );

        add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );

        add_filter( 'template_include', array( $this, 'maybe_use_custom_blog_template' ) );
        add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'wp_head', array( $this, 'output_critical_css' ), 1 );
        add_action( 'widgets_init', array( $this, 'register_sidebar' ) );

        add_filter( 'the_content', array( $this, 'append_single_post_cta' ) );
    }

    public function load_textdomain() {
        load_plugin_textdomain(
            'blog-layout',
            false,
            dirname( plugin_basename( __FILE__ ) ) . '/languages'
        );
    }

}

FBL_Blog_Layout::instance();

endif; // End if class exists.
