<h2><?php esc_html_e( 'Single post CTA', 'blog-layout' ); ?></h2>
<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Enable CTA', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[cta_enabled]" value="1" <?php checked( $opts['cta_enabled'], 1 ); ?> />
                <?php esc_html_e( 'Append CTA block under every blog post', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'CTA title', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[cta_title]" value="<?php echo esc_attr( $opts['cta_title'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'CTA text', 'blog-layout' ); ?></th>
        <td>
            <textarea name="fbl_options[cta_text]" rows="4" class="large-text"><?php echo esc_textarea( $opts['cta_text'] ); ?></textarea>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'CTA button text', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[cta_button_text]" value="<?php echo esc_attr( $opts['cta_button_text'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'CTA button URL', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[cta_button_url]" value="<?php echo esc_attr( $opts['cta_button_url'] ); ?>" />
        </td>
    </tr>
</table>
