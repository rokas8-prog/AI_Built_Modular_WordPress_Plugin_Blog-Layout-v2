<h2><?php esc_html_e( 'Hero section', 'blog-layout' ); ?></h2>
<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Enable hero', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[hero_enabled]" value="1" <?php checked( $opts['hero_enabled'], 1 ); ?> />
                <?php esc_html_e( 'Show hero at the top of blog page', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Use category description on category pages', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[category_use_term_description]" value="1" <?php checked( $opts['category_use_term_description'], 1 ); ?> />
                <?php esc_html_e( 'On category archives replace hero title with category name and subtitle with category description.', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Hero title', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[hero_title]" value="<?php echo esc_attr( $opts['hero_title'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Hero subtitle', 'blog-layout' ); ?></th>
        <td>
            <textarea name="fbl_options[hero_subtitle]" rows="3" class="large-text"><?php echo esc_textarea( $opts['hero_subtitle'] ); ?></textarea>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Hero button text', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[hero_button_text]" value="<?php echo esc_attr( $opts['hero_button_text'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Hero button URL', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[hero_button_url]" value="<?php echo esc_attr( $opts['hero_button_url'] ); ?>" />
        </td>
    </tr>
</table>
