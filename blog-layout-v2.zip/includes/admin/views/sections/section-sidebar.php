<h2><?php esc_html_e( 'Sidebar: categories & default info box', 'blog-layout' ); ?></h2>
<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Show category list block', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[sidebar_show_category_block]" value="1" <?php checked( $opts['sidebar_show_category_block'], 1 ); ?> />
                <?php esc_html_e( 'Show a list of blog categories at the top of sidebar.', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Category block title', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[sidebar_category_block_title]" value="<?php echo esc_attr( $opts['sidebar_category_block_title'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Enable default sidebar info box', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[sidebar_default_enabled]" value="1" <?php checked( $opts['sidebar_default_enabled'], 1 ); ?> />
                <?php esc_html_e( 'Show styled info box when there are no widgets in “Blog Sidebar”.', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Sidebar box title', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[sidebar_default_title]" value="<?php echo esc_attr( $opts['sidebar_default_title'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Sidebar box text', 'blog-layout' ); ?></th>
        <td>
            <textarea name="fbl_options[sidebar_default_text]" rows="4" class="large-text"><?php echo esc_textarea( $opts['sidebar_default_text'] ); ?></textarea>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Sidebar box button text (optional)', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[sidebar_default_button_text]" value="<?php echo esc_attr( $opts['sidebar_default_button_text'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Sidebar box button URL (optional)', 'blog-layout' ); ?></th>
        <td>
            <input type="text" class="regular-text" name="fbl_options[sidebar_default_button_url]" value="<?php echo esc_attr( $opts['sidebar_default_button_url'] ); ?>" />
        </td>
    </tr>
</table>
