<h2><?php esc_html_e( 'Layout', 'blog-layout' ); ?></h2>
<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Layout type', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="radio" name="fbl_options[layout_type]" value="grid" <?php checked( $opts['layout_type'], 'grid' ); ?> />
                <?php esc_html_e( 'Grid (cards)', 'blog-layout' ); ?>
            </label><br />
            <label>
                <input type="radio" name="fbl_options[layout_type]" value="list" <?php checked( $opts['layout_type'], 'list' ); ?> />
                <?php esc_html_e( 'List (image left, text right)', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Columns on desktop', 'blog-layout' ); ?></th>
        <td>
            <input type="number" min="1" max="3" name="fbl_options[columns]" value="<?php echo esc_attr( $opts['columns'] ); ?>" />
            <p class="description"><?php esc_html_e( 'Used only for grid layout. Mobile is always 1 column or as configured below.', 'blog-layout' ); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Sidebar position (desktop)', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="radio" name="fbl_options[sidebar_position]" value="right" <?php checked( $opts['sidebar_position'], 'right' ); ?> />
                <?php esc_html_e( 'Right side (default)', 'blog-layout' ); ?>
            </label><br />
            <label>
                <input type="radio" name="fbl_options[sidebar_position]" value="left" <?php checked( $opts['sidebar_position'], 'left' ); ?> />
                <?php esc_html_e( 'Left side', 'blog-layout' ); ?>
            </label>
            <p class="description"><?php esc_html_e( 'On tablet and mobile the sidebar still drops below the content.', 'blog-layout' ); ?></p>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Apply to category archives', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[apply_to_categories]" value="1" <?php checked( $opts['apply_to_categories'], 1 ); ?> />
                <?php esc_html_e( 'Use this layout on category pages too', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Apply to tag archives', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[apply_to_tags]" value="1" <?php checked( $opts['apply_to_tags'], 1 ); ?> />
                <?php esc_html_e( 'Use this layout on tag pages too', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Show sidebar (desktop & tablet)', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[show_sidebar]" value="1" <?php checked( $opts['show_sidebar'], 1 ); ?> />
                <?php esc_html_e( 'Show right/left sidebar', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Excerpt length (words)', 'blog-layout' ); ?></th>
        <td>
            <input type="number" min="5" max="80" name="fbl_options[excerpt_length]" value="<?php echo esc_attr( $opts['excerpt_length'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Show meta info', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[show_meta_date]" value="1" <?php checked( $opts['show_meta_date'], 1 ); ?> />
                <?php esc_html_e( 'Date', 'blog-layout' ); ?>
            </label><br />
            <label>
                <input type="checkbox" name="fbl_options[show_meta_category]" value="1" <?php checked( $opts['show_meta_category'], 1 ); ?> />
                <?php esc_html_e( 'Category', 'blog-layout' ); ?>
            </label><br />
            <label>
                <input type="checkbox" name="fbl_options[show_meta_readtime]" value="1" <?php checked( $opts['show_meta_readtime'], 1 ); ?> />
                <?php esc_html_e( 'Estimated read time', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
</table>

<h2><?php esc_html_e( 'Responsive (tablet & mobile)', 'blog-layout' ); ?></h2>
<table class="form-table">
    <tr>
        <th scope="row"><?php esc_html_e( 'Columns on tablet (&le; 992px)', 'blog-layout' ); ?></th>
        <td>
            <input type="number" min="1" max="3" name="fbl_options[columns_tablet]" value="<?php echo esc_attr( $opts['columns_tablet'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Columns on mobile (&le; 768px)', 'blog-layout' ); ?></th>
        <td>
            <input type="number" min="1" max="2" name="fbl_options[columns_mobile]" value="<?php echo esc_attr( $opts['columns_mobile'] ); ?>" />
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Hide hero on mobile', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[hide_hero_mobile]" value="1" <?php checked( $opts['hide_hero_mobile'], 1 ); ?> />
                <?php esc_html_e( 'Do not show hero section on small screens', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
    <tr>
        <th scope="row"><?php esc_html_e( 'Hide sidebar on mobile', 'blog-layout' ); ?></th>
        <td>
            <label>
                <input type="checkbox" name="fbl_options[hide_sidebar_mobile]" value="1" <?php checked( $opts['hide_sidebar_mobile'], 1 ); ?> />
                <?php esc_html_e( 'Do not show sidebar on small screens', 'blog-layout' ); ?>
            </label>
        </td>
    </tr>
</table>
