<div class="wrap">
    <h1><?php esc_html_e( 'Blog Layout', 'blog-layout' ); ?></h1>

    <form method="post" action="options.php">
        <?php settings_fields( 'fbl_settings_group' ); ?>

        <?php include __DIR__ . '/sections/section-layout.php'; ?>
        <?php include __DIR__ . '/sections/section-hero.php'; ?>
        <?php include __DIR__ . '/sections/section-cta.php'; ?>
        <?php include __DIR__ . '/sections/section-sidebar.php'; ?>

        <?php submit_button(); ?>
    </form>

    <p class="description">
        <?php esc_html_e( 'Tip: configure the "Blog Sidebar" under Appearance → Widgets.', 'blog-layout' ); ?>
    </p>
</div>
