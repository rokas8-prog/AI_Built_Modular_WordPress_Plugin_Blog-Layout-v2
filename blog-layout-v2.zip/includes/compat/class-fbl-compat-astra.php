<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! class_exists( 'FBL_Compat_Astra' ) ) {
    class FBL_Compat_Astra {

        public static function is_available() {
            return function_exists( 'astra_primary_class' );
        }

        public static function get_archive_primary_wrapper_attributes() {
            if ( ! self::is_available() ) {
                return '';
            }

            ob_start();
            astra_primary_class();
            return trim( ob_get_clean() );
        }

        public static function get_archive_container_classes() {
            return 'fbl-container ast-container';
        }
    }
}
