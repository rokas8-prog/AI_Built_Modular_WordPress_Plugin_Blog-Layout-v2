<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait FBL_Blog_Layout_Public_Trait {

    public function maybe_use_custom_blog_template( $template ) {
        if ( is_admin() ) {
            return $template;
        }

        if ( $this->is_custom_archive_layout_active() ) {
            $custom = plugin_dir_path( $this->get_plugin_base_file_path() ) . 'templates/archive-blog.php';
            if ( file_exists( $custom ) ) {
                return $custom;
            }
        }

        return $template;
    }

    public function register_sidebar() {
        register_sidebar(
            array(
                'name'          => __( 'Blog Sidebar', 'blog-layout' ),
                'id'            => 'fbl-blog-sidebar',
                'description'   => __( 'Sidebar shown on blog pages.', 'blog-layout' ),
                'before_widget' => '<section id="%1$s" class="widget %2$s">',
                'after_widget'  => '</section>',
                'before_title'  => '<h3 class="widget-title">',
                'after_title'   => '</h3>',
            )
        );
    }

    public function append_single_post_cta( $content ) {
        if ( ! is_single() || 'post' !== get_post_type() ) {
            return $content;
        }

        if ( ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }

        if ( empty( $this->options['cta_enabled'] ) ) {
            return $content;
        }

        $title   = isset( $this->options['cta_title'] ) ? $this->options['cta_title'] : '';
        $text    = isset( $this->options['cta_text'] ) ? $this->options['cta_text'] : '';
        $btn_txt = isset( $this->options['cta_button_text'] ) ? $this->options['cta_button_text'] : '';
        $btn_url = isset( $this->options['cta_button_url'] ) ? $this->options['cta_button_url'] : '';

        ob_start();
        ?>
        <div class="fbl-cta">
            <?php if ( $title ) : ?>
                <h2 class="fbl-cta-title"><?php echo esc_html( $title ); ?></h2>
            <?php endif; ?>

            <?php if ( $text ) : ?>
                <?php $cta_text_html_safe = $this->render_plain_textarea_content_with_paragraphs( $text ); ?>
                <div class="fbl-cta-text">
                    <?php echo $cta_text_html_safe; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- sanitized at helper boundary. ?>
                </div>
            <?php endif; ?>

            <?php if ( $btn_txt && $btn_url ) : ?>
                <a class="fbl-cta-btn" href="<?php echo esc_url( $btn_url ); ?>">
                    <?php echo esc_html( $btn_txt ); ?>
                </a>
            <?php endif; ?>
        </div>
        <?php
        $cta_html = ob_get_clean();

        return $content . $cta_html;
    }
}
