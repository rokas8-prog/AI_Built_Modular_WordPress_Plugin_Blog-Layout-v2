<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait FBL_Blog_Layout_Context_Defaults_Trait {

    private function default_options() {
        return array(
            'layout_type'          => 'grid', // grid | list.
            'columns'              => 2,
            'columns_tablet'       => 2,
            'columns_mobile'       => 1,
            'apply_to_categories'  => 1,
            'apply_to_tags'        => 1,
            'show_sidebar'         => 1,
            'excerpt_length'       => 25,
            'show_meta_date'       => 1,
            'show_meta_category'   => 1,
            'show_meta_readtime'   => 1,

            'hero_enabled'         => 1,
            'hero_title'           => __( 'Blog – insights and news', 'blog-layout' ),
            'hero_subtitle'        => __( 'We share useful information, tips, and updates for your readers.', 'blog-layout' ),
            'hero_button_text'     => __( 'Learn more', 'blog-layout' ),
            'hero_button_url'      => '/',
            'hide_hero_mobile'     => 0,
            'category_use_term_description' => 0,

            'cta_enabled'          => 1,
            'cta_title'            => __( 'Want to guide the reader further?', 'blog-layout' ),
            'cta_text'             => __( 'Adapt this CTA block to your needs and direct visitors to your most important page, service, or contact form.', 'blog-layout' ),
            'cta_button_text'      => __( 'Learn more', 'blog-layout' ),
            'cta_button_url'       => '/',

            'sidebar_default_enabled'         => 1,
            'sidebar_default_title'           => __( 'Blog', 'blog-layout' ),
            'sidebar_default_text'            => __( 'Add widgets to the “Blog Sidebar” area to display content here, or customize this block to suit your needs.', 'blog-layout' ),
            'sidebar_default_button_text'     => '',
            'sidebar_default_button_url'      => '',
            'sidebar_show_category_block'     => 1,
            'sidebar_category_block_title'    => __( 'Categories', 'blog-layout' ),
            'hide_sidebar_mobile'             => 0,
            'sidebar_position'                => 'right', // right | left.
        );
    }

    private function normalize_layout_type( $layout_type ) {
        return in_array( $layout_type, array( 'grid', 'list' ), true ) ? $layout_type : 'grid';
    }

    private function normalize_sidebar_position( $sidebar_position ) {
        return in_array( $sidebar_position, array( 'left', 'right' ), true ) ? $sidebar_position : 'right';
    }

    private function normalize_column_value( $value, $default, $max ) {
        $value = is_numeric( $value ) ? (int) $value : (int) $default;

        return max( 1, min( $max, $value ) );
    }

    public function get_normalized_layout_values( $options = array() ) {
        $defaults = $this->default_options();

        return array(
            'layout_type'      => $this->normalize_layout_type(
                isset( $options['layout_type'] ) ? $options['layout_type'] : $defaults['layout_type']
            ),
            'sidebar_position' => $this->normalize_sidebar_position(
                isset( $options['sidebar_position'] ) ? $options['sidebar_position'] : $defaults['sidebar_position']
            ),
            'columns'          => $this->normalize_column_value(
                isset( $options['columns'] ) ? $options['columns'] : $defaults['columns'],
                $defaults['columns'],
                3
            ),
            'columns_tablet'   => $this->normalize_column_value(
                isset( $options['columns_tablet'] ) ? $options['columns_tablet'] : $defaults['columns_tablet'],
                $defaults['columns_tablet'],
                3
            ),
            'columns_mobile'   => $this->normalize_column_value(
                isset( $options['columns_mobile'] ) ? $options['columns_mobile'] : $defaults['columns_mobile'],
                $defaults['columns_mobile'],
                2
            ),
        );
    }

    private function is_astra_archive_compat_active() {
        return defined( 'ASTRA_THEME_VERSION' ) || function_exists( 'astra_primary_class' );
    }

    private function maybe_load_astra_archive_compat() {
        if ( ! $this->is_astra_archive_compat_active() ) {
            return false;
        }

        if ( ! class_exists( 'FBL_Compat_Astra' ) ) {
            require_once dirname( __DIR__ ) . '/compat/class-fbl-compat-astra.php';
        }

        return class_exists( 'FBL_Compat_Astra' ) && FBL_Compat_Astra::is_available();
    }

    private function get_generic_archive_primary_wrapper_attributes() {
        return 'class="content-area fbl-primary"';
    }

    private function get_generic_archive_container_classes() {
        return 'fbl-container';
    }

    public function get_archive_primary_wrapper_attributes() {
        $attributes = $this->get_generic_archive_primary_wrapper_attributes();

        if ( $this->maybe_load_astra_archive_compat() ) {
            $astra_attributes = FBL_Compat_Astra::get_archive_primary_wrapper_attributes();
            if ( '' !== $astra_attributes ) {
                return $astra_attributes;
            }
        }

        return $attributes;
    }

    public function get_archive_container_classes() {
        if ( $this->maybe_load_astra_archive_compat() ) {
            return FBL_Compat_Astra::get_archive_container_classes();
        }

        return $this->get_generic_archive_container_classes();
    }

    private function get_plugin_base_file_path() {
        return dirname( __DIR__, 2 ) . '/blog-layout-v2.php';
    }

    private function is_custom_archive_layout_active() {
        if ( is_home() || is_post_type_archive( 'post' ) ) {
            return true;
        }

        if ( is_category() ) {
            return ! empty( $this->options['apply_to_categories'] );
        }

        if ( is_tag() ) {
            return ! empty( $this->options['apply_to_tags'] );
        }

        return false;
    }

    public function get_main_layout_class_string( $options = array() ) {
        $layout_values = $this->get_normalized_layout_values( $options );
        $sidebar_class = ( 'left' === $layout_values['sidebar_position'] ) ? 'fbl-sidebar-left' : 'fbl-sidebar-right';

        return 'fbl-main-layout ' . ( ! empty( $options['show_sidebar'] ) ? 'fbl-has-sidebar' : 'fbl-no-sidebar' ) . ' ' . $sidebar_class;
    }

    public function get_grid_class_string( $options = array() ) {
        $layout_values = $this->get_normalized_layout_values( $options );

        return 'fbl-grid fbl-cols-' . $layout_values['columns'] . ' layout-' . $layout_values['layout_type'];
    }
}
