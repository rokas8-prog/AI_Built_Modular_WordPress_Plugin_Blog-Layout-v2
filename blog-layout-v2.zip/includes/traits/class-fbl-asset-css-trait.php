<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait FBL_Blog_Layout_Asset_CSS_Trait {

    public function get_dynamic_responsive_column_css_fragment( $options = array(), $compact = false ) {
        $layout_values   = $this->get_normalized_layout_values( $options );
        $columns         = isset( $layout_values['columns'] ) ? (int) $layout_values['columns'] : 1;
        $columns_tablet  = isset( $layout_values['columns_tablet'] ) ? (int) $layout_values['columns_tablet'] : $columns;
        $columns_mobile  = isset( $layout_values['columns_mobile'] ) ? (int) $layout_values['columns_mobile'] : $columns_tablet;

        if ( $compact ) {
            return '.fbl-grid.fbl-cols-' . $columns . '{--fbl-columns-desktop:' . $columns . ';--fbl-columns-tablet:' . $columns_tablet . ';--fbl-columns-mobile:' . $columns_mobile . ';}';
        }

        return '.fbl-grid.fbl-cols-' . $columns . ' { --fbl-columns-desktop: ' . $columns . '; --fbl-columns-tablet: ' . $columns_tablet . '; --fbl-columns-mobile: ' . $columns_mobile . '; }';
    }

    public function get_base_critical_layout_css_fragment() {
        $css  = '';
        $css .= '.fbl-container{width:100%;max-width:var(--fbl-container-max-width,1200px);margin:0 auto;padding:0 15px;}';
        $css .= '.fbl-main-layout{display:flex;gap:var(--fbl-layout-gap,40px);align-items:flex-start;}';
        $css .= '.fbl-main-layout.fbl-no-sidebar{display:block;}';
        $css .= '.fbl-main-layout.fbl-sidebar-left{flex-direction:row-reverse;}';
        $css .= '.fbl-main-layout.fbl-sidebar-right{flex-direction:row;}';
        $css .= '.fbl-content-area{flex:1 1 auto;min-width:0;}';
        $css .= '.fbl-sidebar{width:var(--fbl-sidebar-width,320px);flex:0 0 var(--fbl-sidebar-width,320px);}';
        $css .= '.fbl-grid{display:grid;grid-template-columns:repeat(var(--fbl-columns,var(--fbl-columns-desktop,1)),minmax(0,1fr));gap:var(--fbl-grid-gap,30px);}';
        $css .= '.fbl-grid.layout-list{grid-template-columns:1fr;}';
        $css .= '.fbl-card-thumb img,.fbl-card-thumb-placeholder{display:block;width:100%;height:var(--fbl-thumbnail-height,210px);}';
        $css .= '@media (max-width: 991.98px){.fbl-main-layout{flex-direction:column;}.fbl-sidebar{width:100%;flex:0 0 auto;}.fbl-grid{--fbl-columns:var(--fbl-columns-tablet,var(--fbl-columns-desktop,1));}}';
        $css .= '@media (max-width: 767.98px){.fbl-grid{--fbl-columns:var(--fbl-columns-mobile,var(--fbl-columns-tablet,var(--fbl-columns-desktop,1)));}}';

        return $css;
    }

    public function get_mobile_visibility_css_fragment( $options = array(), $important = false, $compact = false ) {
        $css             = '';
        $important_value = $important ? '!important' : '';

        if ( ! empty( $options['hide_hero_mobile'] ) ) {
            if ( $compact ) {
                $css .= '@media (max-width: 767.98px){.fbl-hero{display:none' . $important_value . ';}}';
            } else {
                $css .= '@media (max-width: 767.98px){ .fbl-hero{ display:none' . $important_value . '; } }';
            }
        }

        if ( ! empty( $options['hide_sidebar_mobile'] ) ) {
            if ( $compact ) {
                $css .= '@media (max-width: 767.98px){.fbl-sidebar{display:none' . $important_value . ';}.fbl-main-layout{display:block' . $important_value . ';}}';
            } else {
                $css .= '@media (max-width: 767.98px){ .fbl-sidebar{ display:none' . $important_value . '; } .fbl-main-layout{ display:block' . $important_value . '; } }';
            }
        }

        return $css;
    }

    public function enqueue_assets() {
        $is_archive_context = $this->is_custom_archive_layout_active();
        $is_single_post_cta = is_singular( 'post' ) && ! empty( $this->options['cta_enabled'] );

        if ( ! ( $is_archive_context || $is_single_post_cta ) ) {
            return;
        }

        $plugin_file = $this->get_plugin_base_file_path();

        if ( $is_archive_context ) {
            wp_enqueue_style(
                'fbl-frontend',
                plugin_dir_url( $plugin_file ) . 'assets/css/frontend.css',
                array(),
                FBL_PLUGIN_VERSION
            );
        } elseif ( $is_single_post_cta ) {
            wp_enqueue_style(
                'fbl-single-cta',
                plugin_dir_url( $plugin_file ) . 'assets/css/single-cta.css',
                array(),
                FBL_PLUGIN_VERSION
            );
        }

        if ( $is_archive_context && ! empty( $this->options['show_sidebar'] ) && ! empty( $this->options['sidebar_show_category_block'] ) ) {
            // Category list expand/collapse (adds toggle buttons for parent categories).
            wp_enqueue_script(
                'fbl-frontend-js',
                plugin_dir_url( $plugin_file ) . 'assets/js/frontend.js',
                array(),
                FBL_PLUGIN_VERSION,
                true
            );

            wp_localize_script(
                'fbl-frontend-js',
                'FBLFrontendL10n',
                array(
                    'toggleSubcategoriesAriaLabel' => __( 'Toggle subcategories', 'blog-layout' ),
                )
            );
        }

        if ( $is_archive_context ) {
            $custom_css  = $this->get_dynamic_responsive_column_css_fragment( $this->options );
            $custom_css .= $this->get_mobile_visibility_css_fragment( $this->options );

            wp_add_inline_style( 'fbl-frontend', $custom_css );
        }
    }

    /**
     * Output minimal critical CSS in <head> to prevent CLS/layout shifts above-the-fold.
     * This is intentionally duplicated from frontend.css so layout is stable even if CSS is deferred/aggregated.
     */
    public function output_critical_css() {
        if ( is_admin() ) {
            return;
        }

        if ( ! $this->is_custom_archive_layout_active() ) {
            return;
        }

        $opts = $this->options;

        $responsive_columns_css = $this->get_dynamic_responsive_column_css_fragment( $opts, true );
        $mobile_visibility_css  = $this->get_mobile_visibility_css_fragment( $opts, true, true );

        // Minimal CSS required to stabilize initial layout.
        $css  = $this->get_base_critical_layout_css_fragment();

        // Dynamic columns and option-dependent mobile visibility.
        if ( '' !== $responsive_columns_css ) {
            $css .= $responsive_columns_css;
        }
        if ( '' !== $mobile_visibility_css ) {
            $css .= $mobile_visibility_css;
        }

        $critical_css = (string) $css;

        echo '<style id="fbl-critical-css">' . $critical_css . '</style>';
    }
}
