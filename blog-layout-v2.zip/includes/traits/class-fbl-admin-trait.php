<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait FBL_Blog_Layout_Admin_Trait {

    public function add_settings_page() {
        add_options_page(
            __( 'Blog Layout', 'blog-layout' ),
            __( 'Blog Layout', 'blog-layout' ),
            'manage_options',
            'blog-layout',
            array( $this, 'render_settings_page' )
        );
    }

    public function register_settings() {
        register_setting( 'fbl_settings_group', 'fbl_options', array( $this, 'sanitize_options' ) );
    }

    public function sanitize_options( $input ) {
        $output = $this->options;

        if ( ! is_array( $input ) ) {
            $input = array();
        }

        $bool_fields = array(
            'apply_to_categories',
            'apply_to_tags',
            'show_sidebar',
            'show_meta_date',
            'show_meta_category',
            'show_meta_readtime',
            'hero_enabled',
            'cta_enabled',
            'sidebar_default_enabled',
            'sidebar_show_category_block',
            'hide_hero_mobile',
            'hide_sidebar_mobile',
            'category_use_term_description',
        );

        foreach ( $bool_fields as $field ) {
            $output[ $field ] = isset( $input[ $field ] ) ? 1 : 0;
        }

        $layout_values = $this->get_normalized_layout_values( $input );
        $output['layout_type'] = $layout_values['layout_type'];
        $output['columns'] = $layout_values['columns'];
        $output['columns_tablet'] = $layout_values['columns_tablet'];
        $output['columns_mobile'] = $layout_values['columns_mobile'];

        $excerpt_length = isset( $input['excerpt_length'] ) ? intval( $input['excerpt_length'] ) : 25;
        $output['excerpt_length'] = max( 5, min( 80, $excerpt_length ) );

        $output['sidebar_position'] = $layout_values['sidebar_position'];

        $url_fields = array(
            'hero_button_url',
            'cta_button_url',
            'sidebar_default_button_url',
        );

        foreach ( $url_fields as $field ) {
            if ( isset( $input[ $field ] ) ) {
                $output[ $field ] = esc_url_raw( $input[ $field ] );
            }
        }

        $single_line_text_fields = array(
            'hero_title',
            'hero_button_text',
            'cta_title',
            'cta_button_text',
            'sidebar_default_title',
            'sidebar_default_button_text',
            'sidebar_category_block_title',
        );

        foreach ( $single_line_text_fields as $field ) {
            if ( isset( $input[ $field ] ) ) {
                $output[ $field ] = sanitize_text_field( $input[ $field ] );
            }
        }

        $multi_line_text_fields = array(
            'hero_subtitle',
            'cta_text',
            'sidebar_default_text',
        );

        foreach ( $multi_line_text_fields as $field ) {
            if ( isset( $input[ $field ] ) ) {
                $output[ $field ] = sanitize_textarea_field( $input[ $field ] );
            }
        }

        return $output;
    }

    public function render_settings_page() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        $opts = $this->options;
        include dirname( __DIR__ ) . '/admin/views/settings-page.php';
    }
}
