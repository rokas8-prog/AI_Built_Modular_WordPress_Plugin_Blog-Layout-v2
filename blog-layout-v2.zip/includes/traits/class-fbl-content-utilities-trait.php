<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait FBL_Blog_Layout_Content_Utilities_Trait {

    public function get_archive_card_thumbnail_html( $post_id ) {
        if ( has_post_thumbnail( $post_id ) ) {
            return get_the_post_thumbnail( $post_id, 'large' );
        }

        $first_img = self::get_first_content_image( $post_id );
        if ( $first_img ) {
            return '<img src="' . esc_url( $first_img ) . '" alt="' . esc_attr( get_the_title( $post_id ) ) . '" />';
        }

        return '<div class="fbl-card-thumb-placeholder"></div>';
    }

    public function get_archive_card_excerpt_text( $post_id, $options = array() ) {
        $excerpt_len = isset( $options['excerpt_length'] ) ? (int) $options['excerpt_length'] : 25;
        $excerpt     = get_the_excerpt( $post_id );

        return wp_trim_words( $excerpt, $excerpt_len );
    }

    public function get_archive_card_read_time_value( $post_id ) {
        return self::estimated_read_time( $post_id );
    }

    public function render_plain_textarea_content_with_paragraphs( $text ) {
        if ( '' === (string) $text ) {
            return '';
        }

        $safe_paragraph_html = wpautop( esc_html( (string) $text ) );

        return wp_kses_post( (string) $safe_paragraph_html );
    }

    public static function estimated_read_time( $post_id ) {
        $content = get_post_field( 'post_content', $post_id );
        $content = wp_strip_all_tags( (string) $content );
        $content = html_entity_decode( $content, ENT_QUOTES, get_bloginfo( 'charset' ) ?: 'UTF-8' );

        $word_count = 0;
        if ( '' !== trim( $content ) ) {
            $matched = preg_match_all( '/[\p{L}\p{N}][\p{L}\p{N}\p{M}\p{Pc}\x{2019}\'\-]*/u', $content, $matches );
            if ( false !== $matched ) {
                $word_count = (int) $matched;
            } else {
                $parts      = preg_split( '/\s+/u', trim( $content ) );
                $word_count = is_array( $parts ) ? count( array_filter( $parts, 'strlen' ) ) : 0;
            }
        }

        if ( $word_count <= 0 ) {
            return 1;
        }

        return max( 1, (int) ceil( $word_count / 200 ) );
    }

    public static function get_first_content_image( $post_id ) {
        $content = get_post_field( 'post_content', $post_id );
        if ( ! $content ) {
            return '';
        }

        if ( class_exists( 'WP_HTML_Tag_Processor' ) ) {
            $processor = new WP_HTML_Tag_Processor( $content );

            while ( $processor->next_tag( array( 'tag_name' => 'IMG' ) ) ) {
                $src = $processor->get_attribute( 'src' );
                if ( is_string( $src ) && '' !== $src ) {
                    return $src;
                }
            }
        }

        if ( preg_match( '/<img[^>]+src=[\'\"]([^\'\"]+)[\'\"][^>]*>/i', $content, $matches ) ) {
            return $matches[1];
        }

        return '';
    }
}
