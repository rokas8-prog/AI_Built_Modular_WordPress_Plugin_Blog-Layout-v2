<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

trait FBL_Blog_Layout_Archive_Template_Data_Trait {

    public function should_render_archive_hero( $options = array() ) {
        return ! empty( $options['hero_enabled'] );
    }

    public function get_archive_hero_payload( $options = array() ) {
        $payload = array(
            'title'       => isset( $options['hero_title'] ) ? $options['hero_title'] : '',
            'subtitle'    => isset( $options['hero_subtitle'] ) ? $options['hero_subtitle'] : '',
            'button_text' => isset( $options['hero_button_text'] ) ? $options['hero_button_text'] : '',
            'button_url'  => isset( $options['hero_button_url'] ) ? $options['hero_button_url'] : '',
        );

        if ( $this->should_render_archive_hero( $options ) && is_category() && ! empty( $options['category_use_term_description'] ) ) {
            $cat_name  = single_cat_title( '', false );
            $term_desc = term_description();

            if ( ! empty( $cat_name ) ) {
                $payload['title'] = $cat_name;
            }

            if ( ! empty( $term_desc ) ) {
                $payload['subtitle'] = wp_strip_all_tags( $term_desc );
            } else {
                $payload['subtitle'] = '';
            }
        }

        return apply_filters( 'fbl_archive_hero_payload', $payload, $options );
    }

    public function get_archive_category_block_payload( $options = array() ) {
        return array(
            'show'              => ! empty( $options['sidebar_show_category_block'] ),
            'title'             => isset( $options['sidebar_category_block_title'] ) ? $options['sidebar_category_block_title'] : '',
            'toggle_aria_label' => __( 'Toggle subcategories', 'blog-layout' ),
        );
    }

    public function get_archive_card_meta_payload( $post_id, $options = array() ) {
        $show_date     = ! empty( $options['show_meta_date'] );
        $show_readtime = ! empty( $options['show_meta_readtime'] );

        return array(
            'show'           => $show_date || $show_readtime,
            'show_date'      => $show_date,
            'date'           => $show_date ? get_the_date( '', $post_id ) : '',
            'show_readtime'  => $show_readtime,
            'read_time'      => $show_readtime ? $this->get_archive_card_read_time_value( $post_id ) : 0,
            'show_separator' => $show_date && $show_readtime,
        );
    }

    public function get_archive_pagination_args() {
        $args = array(
            'prev_text' => '&laquo;',
            'next_text' => '&raquo;',
        );

        return apply_filters( 'fbl_archive_pagination_args', $args );
    }

    public function get_archive_sidebar_visibility_state( $options = array() ) {
        return array(
            'show_sidebar'       => ! empty( $options['show_sidebar'] ),
            'use_widget_sidebar' => is_active_sidebar( 'fbl-blog-sidebar' ),
            'show_default_box'   => ! empty( $options['sidebar_default_enabled'] ),
        );
    }

    public function get_sidebar_default_box_payload( $options = array() ) {
        $payload = array(
            'title'       => isset( $options['sidebar_default_title'] ) ? $options['sidebar_default_title'] : '',
            'text'        => isset( $options['sidebar_default_text'] ) ? $options['sidebar_default_text'] : '',
            'button_text' => isset( $options['sidebar_default_button_text'] ) ? $options['sidebar_default_button_text'] : '',
            'button_url'  => isset( $options['sidebar_default_button_url'] ) ? $options['sidebar_default_button_url'] : '',
        );

        return apply_filters( 'fbl_sidebar_default_box_payload', $payload, $options );
    }

    public function get_archive_card_primary_category_name( $post_id ) {
        $cats = get_the_category( $post_id );
        if ( ! empty( $cats ) ) {
            return $cats[0]->name;
        }

        return '';
    }
}
